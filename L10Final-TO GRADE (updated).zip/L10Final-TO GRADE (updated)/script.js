const axios = require("axios");
const URL = "http://localhost:3000/staff";
//hogwarts-staff.json
//https://jsonplaceholder.typicode.com/posts

// https://jsonplaceholder.typicode.com/comments?postId=1

const data = {
    name: "Ayana Labossiere Burks",
    email: "adlabossiere@gmail.com",
    body: "New Hogwarts Professor",
}

const editData = {
    name: "Linda Villanueva",
    email: "linda.villanueva@learningsource.com",
    body: "New Hogwarts Professor of Charms"
    
}


axios
    .get(URL)
    .then((response) => {

        console.log(response.data);

    })
    //.then(data => console.log(data));


axios
    .post(URL, data)
    .then((response) => {
    
        console.log(response);

    });


axios
    .put("http://localhost:3000/staff/4", editData)
    .then((response) => {
    
        console.log(response);
        // https://jsonplaceholder.typicode.com/comments/2
    });

axios
    .delete("http://localhost:3000/staff/0")
    .then((response) => {
// https://jsonplaceholder.typicode.com/comments/5
        console.log(response);
});








// add = function(){

// };


// edit = function(){

// };


// delete = function(){

// };

// function showData() {
//     document.getElementById("crudData").style.display = "show";
// }


    // showData() {
    //     alert("Hello");
    // } 
    
    


//DIFFERENT THINGS TRIED AND NOT USED
//Axios had a lot of problems working with basic elements in my JS like "document.getElementById"
//const axios = require("axios");
//const { default: axios } = require("axios");

//AXIOS FUNCTIONS
//then do show and hide the data function


// axios
//     .get(URL)
//     .then((response) => {
//         console.log(response.data);
//         //return response.json();
//         //axiosData.innerHTML = response.data;
//     })